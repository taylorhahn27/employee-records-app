# Prep for seeding database with Python #
1) Install Python install
2 Download pgAdmin 4 -- https://www.postgresql.org/ftp/pgadmin/pgadmin4/v4.3/macos/
3) Open terminal to employee-records-app/utils/ directory
4) Enter the following command into terminal: pip3 install -r requirements.txt
